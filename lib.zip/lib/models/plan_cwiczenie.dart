import 'package:gym_tracker_app/services/db_fields.dart';

class PlanCwiczenie {
  final int? planId;
  final int? cwiczenieId;

  PlanCwiczenie({this.planId, this.cwiczenieId});

  factory PlanCwiczenie.fromMap(Map<String, dynamic> map) => PlanCwiczenie(
    planId: map[DbFields.planExercisePlanId],
    cwiczenieId: map[DbFields.planExerciseExerciseID],
  );

  Map<String, dynamic> toMap() => {
    DbFields.planExercisePlanId: planId,
    DbFields.planExerciseExerciseID: cwiczenieId,
  };
}
