import 'package:gym_tracker_app/services/db_fields.dart';

class PlanyTreningowe {
  final int? id;
  final String? nazwaPlanu;
  final String? opisPlanu;

  PlanyTreningowe({this.id, this.nazwaPlanu, this.opisPlanu});

  factory PlanyTreningowe.fromMap(Map<String, dynamic> map) {
    return PlanyTreningowe(

      id: map[DbFields.planId],
      nazwaPlanu: map[DbFields.planName],
      opisPlanu: map[DbFields.planDesc] 
    );
  }

  Map<String, dynamic> toMap() {
    return {
      DbFields.planId: id,
      DbFields.planName: nazwaPlanu,
      DbFields.planDesc: opisPlanu,
    };
  }

  PlanyTreningowe copyWith({int? id, String? nazwaPlanu, String? opisPlanu}) {
    return PlanyTreningowe(
      id: id ?? this.id,
      nazwaPlanu: nazwaPlanu ?? this.nazwaPlanu,
      opisPlanu: opisPlanu ?? this.opisPlanu,
    );
  }
  
}
