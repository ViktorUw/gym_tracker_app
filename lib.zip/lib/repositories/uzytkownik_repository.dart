import 'package:gym_tracker_app/models/uzytkownik.dart';
import 'package:gym_tracker_app/services/database_services.dart';
import 'package:gym_tracker_app/services/db_fields.dart';

class UserRepository {
  Future<int> insertUser(Uzytkownik user) async{
    final db = await DatabaseServices.instance.database;
    return await db.insert(DbFields.tableUser, user.toMap());
  }

  Future<List<Uzytkownik>> getAllUser() async {
    final db = await DatabaseServices.instance.database;
    final result = await db.query(DbFields.tableUser);
    return result.map((e) => Uzytkownik.fromMap(e)).toList();

  }

  Future<int> updateUser(Uzytkownik user) async {
    final db = await DatabaseServices.instance.database;
    return await db.update(
      DbFields.tableUser,
      user.toMap(),
      where: '${DbFields.userId} = ?',
      whereArgs: [user.id],
    );
  }

  Future<int> deleteUser(int id) async {
    final db = await DatabaseServices.instance.database;
    return await db.delete(
      DbFields.tableUser,
      where: '${DbFields.userId} = ?',
      whereArgs: [id],
    );
  }
}