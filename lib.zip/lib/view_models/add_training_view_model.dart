import 'package:flutter/material.dart';
import 'package:gym_tracker_app/models/trening_wykonany.dart';
import 'package:gym_tracker_app/repositories/trening_wykonany_repository.dart';

class AddTrainingViewModel extends ChangeNotifier {
  final TreningWykonanyRepository _repo = TreningWykonanyRepository();

  bool isLoading = false;
  String? errorMsg;

  Future<bool> addTraining(TreningWykonany training) async {
    isLoading = true;
    errorMsg = null;
    notifyListeners();
      try {
      await _repo.insertTraining(training);
      isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      isLoading = false;
      errorMsg = e.toString();
      notifyListeners();
      return false;
    }
  }
  
}